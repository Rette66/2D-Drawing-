
Wenxiu Wei

this is a simple 2d drawing machine
all same shape are using same VBO

left click the mouse to draw a shape on the canvas. 
hold on the left mouse and move mouse will rotate the shape.
the default shape is a triangle and the color is red.
you can press r,g,b to change color and p,h,v,t,q, R to change shape

r - red
g - green
b - blue
p - point
h - horizontal line
v - vertical line
t - triangle 
q - square
R - circle
s - shrink
S - enlarge
W - enable gloable transformation(could not draw now)
w - close globale transformation

I have implemented my own matrix arithmetic functions,

press d to clear the last shape
you can also press c to clear the screen

2/6/2023